function setup() {
  createCanvas(1250, 550);
}

function draw() {
  

  //Water
  background(0, 199, 249);
  
 
  
  //Sand code
  fill(255,248,220);
  rect(0,410,1250, 200);
  
  fill(0, 0, 0);
  circle(30,440, 2);
  circle(100, 440, 2);
  circle(180, 440, 2);
  circle(250, 440, 2);
  circle(320, 440, 2);
  circle(400, 440, 2);
  circle(480, 440, 2);
  circle(550, 440, 2);
  circle(620, 440, 2);
  circle(690, 440, 2);
  circle(770, 440, 2);
  circle(1190, 440, 2);
  
  circle(70, 480, 2);
  circle(150, 480, 2);
  circle(230, 480, 2);
  circle(300, 480, 2);
  circle(370, 480, 2);
  circle(450, 480, 2);
  circle(530, 480, 2);
  circle(600, 480, 2);
  circle(670, 480, 2);
  circle(730, 480, 2);
  circle(800, 480, 2);
  circle(870, 480, 2);
  circle(930, 480, 2);
  circle(1000, 480, 2);
  circle(1070, 480, 2);
  circle(1130, 480, 2);
  circle(1220, 480, 2);
  
  circle(30,520, 2);
  circle(100, 520, 2);
  circle(180, 520, 2);
  circle(250, 520, 2);
  circle(320, 520, 2);
  circle(400, 520, 2);
  circle(480, 520, 2);
  circle(550, 520, 2);
  circle(620, 520, 2);
  circle(690, 520, 2);
  circle(770, 520, 2);
  circle(840, 520, 2);
  circle(900, 520,2);
  circle(960, 520, 2);
  circle(1040, 520, 2);
  circle(1100, 520 , 2);
  circle(1180, 520, 2);

  //Bubble Fish Tank Chest

  
  fill(0, 0, 0,);
  rect(848, 300, 317, 50);
  
fill(139, 69, 19);
  quad(1100, 180, 890, 180, 850, 290, 1159, 290);
  quad(847, 360, 1160,360, 1110,460, 910,460);


  
  fill(218, 165, 85);
  rect(846, 347, 317, 15);
  rect(848, 290, 317, 15);
  rect(890,176, 211, 15);
  rect(905,446, 211, 15);
  rect(935, 191, 15, 255);
  rect(1050, 191, 15, 255);
  
  
  
  fill(0, 0, 0,);
  rect(860, 261, 285, 4);
  rect(872, 229, 253, 4);
  
  rect(866, 385, 280, 4);
  rect(887, 419, 243, 4);
  


  
  
  //Gold Coins
  fill(218, 165, 85);
  circle(860, 298, 12);
  circle(900, 298, 12);
 
  
  circle(942, 298, 12);
  circle(942, 354, 12);
  circle(942, 387, 12);
  circle(942, 420, 12);
  circle(942, 454, 12);
  
  circle(1057, 198, 12);
  circle(1057, 254, 12);
  circle(1057, 287, 12);
  circle(1057, 320, 12);
  circle(1057, 454, 12);
  

  
  quad(847,362, 857, 362, 920,447, 901, 447);
  quad(1163, 362, 1153, 362, 1093, 446, 1115, 446);
  quad(890, 178, 903, 178, 863, 290, 847, 290);
  quad(1090, 182, 1106, 182, 1167, 290, 1147, 290);
  
  fill(0, 0, 0,);
  rect(868, 305, 275, 42);
  
  //Coral code
  fill(0, 255, 0);
  rect(101,233,5,210);
  rect(121,233,5,210);
  rect(131,233,5,210);
  rect(611,233,5,210);
  rect(621,233,5,210);
  rect(631,233,5,210);
  
  //Toy Castle
fill(200, 200, 200);
rect(300,100,150,340);

rect(300, 80, 20, 20);
rect(380, 80, 20, 20);
rect(340, 80, 20, 20);
rect(430, 80, 20, 20);

 fill(0, 0, 0,);
rect(300, 271, 150, 4);
rect(300, 301, 150, 4);
rect(300, 341, 150, 4);
rect(300, 381, 150, 4);
rect(300, 421, 150, 4);
rect(300, 241, 150, 4);

 fill(0, 199, 249);
circle(373,160, 100);

fill(200, 200, 200);
rect(300,170,150,40);
  
   
  // Repitisious Fish
 
//body
fill(255, 140, 0); 
circle(mouseX, mouseY, 20);
ellipse(mouseX, mouseY, 35, 20);
triangle(mouseX - 14, mouseY,
        mouseX - 30, mouseY -11,
        mouseX - 30, mouseY + 10);
//eyes
fill(0); 
circle(mouseX + 8, mouseY - 3, 3);

//Bubbles
noStroke(); 
fill(255, 255, 255, 120);
circle(500, 20, 20);
circle(800, 60, 20);
circle(700, 120, 20);
circle(600, 200, 20);
circle(820, 320, 20);
circle(200, 220, 20);
circle(100, 30, 20);
circle(1200, 50, 20);
circle(1050, 70, 20);
  
  
//The boring math needed
let swim = abs(mouseX - 300);
  
let angle = radians(40);
  
  
}