let stars = [];
let trail1 = [];
let trail2 = [];
let trail3 = [];
let lbike1X = 260;
let lbike2X = 360;
let lbike3X = 290;


function setup() {
createCanvas(1200, 400);

  for (let i = 0; i < 50; i++) {
  stars[i] = random(width);
}  
  
}

function draw() {
background(0);

//To meet the demands for the assignment
  console.log(trail1.length);
  
 fill(255);
for (let i = 0; i < stars.length; i++) {
  ellipse(stars[i], i * 8, 3, 3);  
  stars[i] += 0.5;                 // motion
  if (stars[i] > width) stars[i] = 0;
} 
  
stars[0] = mouseX;  
  
//: The Grid  
 stroke(135, 206, 250);
line(0, 200, 1200, 200);
line(0, 230, 1200, 230); 
line(0, 275, 1200, 275);
line(0, 300, 1200, 300);  
line(0, 213, 1200, 213);
line(0, 370, 1200, 370);
line(0, 250, 1200, 250);
line(0, 320, 1200, 320); 
line(0, 345, 1200, 345); 
stroke(135, 206, 250);

function vLine(x) {

  let vp = 1000;

  let shift = (x - vp) * 0.25;

  line(x, 200, x + shift, 410);
}

for (let x = 0; x <= 2000; x += 30) {
  vLine(x);
} 
 
  
  
  
//: The Light Bikes   
trail1.push({ x: lbike1X, y: 244 });
trail2.push({ x: lbike2X, y: 283 });
trail3.push({ x: lbike3X, y: 344 });
  
fill(135, 206, 250);
ellipse(lbike1X + 20, 244, 62, 20); 
ellipse(lbike1X + 0, 250, 28, 28); 
ellipse(lbike1X + 40, 250, 28, 28); 

fill(0);
ellipse(lbike1X + 0, 250, 18, 18);
ellipse(lbike1X + 40, 250, 18, 18);
fill(0);
arc(lbike1X + 27, 244, 30, 18, PI + 0.2, TWO_PI - 0.2);
  
  

fill(255, 255, 0);
ellipse(lbike2X + 20, 283, 62, 20);
ellipse(lbike2X + 0, 290, 28, 28);
ellipse(lbike2X + 40, 290, 28, 28); 
fill(0);
ellipse(lbike2X + 0, 290, 18, 18);
ellipse(lbike2X + 40, 290, 18, 18);
arc(lbike1X + 127, 283, 30, 18, PI + 0.2, TWO_PI - 0.2);
  
  
  

fill(255, 165, 0);
ellipse(lbike3X + 20, 344, 62, 20);
ellipse(lbike3X + 0, 350, 28, 28);
ellipse(lbike3X + 40, 350, 28, 28);
fill(0);
ellipse(lbike3X + 0, 350, 18, 18);
ellipse(lbike3X + 40, 350, 18, 18);
arc(lbike1X + 57, 344, 30, 18, PI + 0.2, TWO_PI - 0.2);  
  
// Blue trail
noStroke();
fill(135, 206, 250, 120);
for (let t of trail1) {
  rect(t.x, t.y - 10, 1, 20);   
}

// Yellow trail
fill(255, 255, 0, 120);
for (let t of trail2) {
  rect(t.x, t.y - 10, 1, 20);
}

// Orange trail
fill(255, 165, 0, 120);
for (let t of trail3) {
  rect(t.x, t.y - 10, 1, 20);
} 

lbike1X++;
lbike2X++;
lbike3X++;
  
}

