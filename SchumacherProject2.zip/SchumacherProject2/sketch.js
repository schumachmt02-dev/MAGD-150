let fireStarted = false;
let flicker = 0;
let stars = [];
let embers = [];
let headAngle = 0;

function setup() {
  createCanvas(1250, 1000);
  background(0);

  // stars
  for (let i = 0; i < 200; i++) {
    stars.push({
      x: random(width),
      y: random(height),
      size: random(1, 4)
    });
    headAngle = atan2(mouseY - 365, mouseX - 505);
  }

  
  // embers
  for (let i = 0; i < 40; i++) {
    embers.push({
      x: 721 + random(-20, 20),
      y: 902 + random(-10, 10),
      speed: random(0.5, 2),
      size: random(2, 5)
    });
  }
}

function draw() {
  drawNightSky();
  drawTrees();

  if (!fireStarted) {
    fill(0);
    noStroke();
    rect(0, 600, width, 400);  
    return;
  }
  flicker = random(-8, 8);

  drawGround();
  drawFire();
  drawEmbers();
}

function mousePressed() {
  fireStarted = true;
}

//The night sky
function drawNightSky() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let r = lerp(0, 25, inter);
    let g = lerp(0, 60, inter);
    let b = lerp(0, 120, inter);
    stroke(r, g, b);
    line(0, y, width, y);
  }

  noStroke();
  fill(255);
for (let s of stars) {
    circle(s.x, s.y, s.size);
  }
}

//The ground with khnight
function drawGround() {
  fill(0, 0, 2);
  rect(0, 600, width, 400);
  fill(0, 0, 2);
  rect(3830, 600, 11, 400);
  
  fill(30, 40, 2);
  circle(573, 878, 500);
  
  fill(0,0,0);
  line(415,502,408,526);

  //wodden stump
  fill(100, 40, 0); 
  rect(465, 580, 80, 110, 5); 
  fill(150, 55, 0); 
  ellipse(505, 580, 80, 15); 

 
   //khight
  fill(255, 230, 210);
  rect(488, 400, 35);
  

  //helmet
  fill(60, 65, 70);
  rect(475, 344, 60, 75);
  circle(505, 355, 60);
  fill(0,0,0);
  
  rect(477, 370, 55 ,6);
  rect(500, 370, 12, 48);
  
  //sword
  fill(255, 200); 
  rect(322, 518, 5, 180); 


  
  //body/ armor
  fill(255,250);
  ellipse(505, 490, 80, 122); 
  rect(472, 510, 70, 90);
  rect(470, 590, 70, 70);

  fill(0,0,0);
  rect(500, 460, 12, 72);
  rect(480, 490, 55 ,12);
  rect(471, 559, 55, 10);
  
  fill(60, 65, 70);
  stroke(60, 65, 70); 
  strokeWeight(25);   
  
  line(545, 460, 593, 510); 
  line(590, 500, 543, 568);
  rect(320, 515, 10, 10)
  
  line(465, 460, 419, 519);
  line(410, 514, 348, 515);
 
  noStroke();
  fill(60, 65, 70);
  circle(545, 460, 40);
  circle(465, 460, 40); 
 
  //legs
  fill(60, 65, 70);
  stroke(60, 65, 70); 
  strokeWeight(35);   
  
  line(465, 585,407, 626); 
  line(407, 626, 411, 710);
  
  line(535, 576, 569, 613);
  line(569, 613, 580, 704);
  
  //boots//legs
  fill(128);
  stroke(60, 65, 70); 
  strokeWeight(38);   
  
  line(415, 706, 389, 726); 
  line(573, 705, 606, 727);
  
}


//trees
function drawTrees() {
  fill(0);

  rect(852, -1, 40, 1680);
  rect(1068, -2, 40, 1631);
  rect(9, -2, 20, 1626);
  rect(732, -203, 10, 1426);
  rect(78, -4, 120, 1111);
  rect(150, -100, 25, 1550);
  rect(220, -80, 20, 1520);
  rect(300, -120, 30, 1560);

  rect(500, -90, 22, 1540);
  rect(580, -110, 18,1520);
  rect(650, -70, 26, 1580);

  rect(900, -100, 24, 1550);
  rect(980, -80, 20, 1520);
  rect(1050, -130, 28, 1570);
  
  stroke(0);
  strokeWeight(3);
  

line(872, 120, 840, 150);
line(872, 200, 910, 230);
line(872, 300, 835, 330);
line(872, 400, 915, 430);
line(1088, 100, 1050, 130);
line(1088, 180, 1125, 210);
line(1088, 260, 1055, 290);
line(1088, 340, 1128, 370);
line(19, 80, -5, 110);
line(19, 150, 45, 180);
line(19, 230, -10, 260);
line(19, 310, 50, 340);
line(737, 250, 720, 270);
line(737, 310, 755, 330);
line(737, 370, 718, 390);
line(737, 430, 758, 450);
line(138, 120, 70, 160);
line(138, 220, 210, 260);
line(138, 320, 60, 360);
line(138, 420, 225, 460);
line(162, 160, 135, 185);
line(162, 240, 190, 265);
line(162, 320, 135, 345);
line(162, 400, 195, 425);
line(230, 140, 205, 165);
line(230, 210, 255, 235);
line(230, 280, 200, 305);
line(230, 350, 260, 375);
line(315, 180, 280, 210);
line(315, 260, 350, 290);
line(315, 340, 280, 370);
line(315, 420, 355, 450);
line(511, 150, 485, 175);
line(511, 230, 540, 255);
line(511, 310, 480, 335);
line(511, 390, 545, 415);
line(589, 170, 565, 195);
line(589, 240, 610, 265);
line(589, 310, 560, 335);
line(589, 380, 615, 405);
line(663, 140, 630, 170);
line(663, 220, 695, 250);
line(663, 300, 630, 330);
line(663, 380, 700, 410);
line(912, 160, 880, 190);
line(912, 240, 940, 270);
line(912, 320, 880, 350);
line(912, 400, 945, 430);
line(990, 140, 965, 165);
line(990, 210, 1015, 235);
line(990, 280, 960, 305);
line(990, 350, 1020, 375);
line(1064, 190, 1030, 220);
line(1064, 270, 1095, 300);
line(1064, 350, 1035, 380);
line(1064, 430, 1100, 460);
line(330, 122, 372, 170);
line(237, 82, 271, 125);
line(24, 25, 64, 74);

  noStroke();
}

//fire
function drawFire() {
  noStroke();
  fill(255, 69, 0);
  beginShape();
  vertex(601 - 10, 926 + 10);
  vertex(606 - 10, 820 + flicker - 10);
  vertex(616 - 10, 890 + 10);
  vertex(626 - 10, 800 + flicker - 10);
  vertex(636 - 10, 870 + 10);
  vertex(646 - 10, 780 + flicker - 10);
  vertex(656 - 10, 880 + 10);
  vertex(666 - 10, 750 + flicker * 1.3 - 10);
  vertex(676 - 10, 860 + 10);
  vertex(686 - 10, 790 + flicker - 10);
  vertex(696 - 10, 880 + 10);
  vertex(706 - 10, 810 + flicker - 10);
  vertex(716 - 10, 890 + 10);
  vertex(726 - 10, 830 + flicker - 10);
  vertex(734 - 10, 895 + 10);
  vertex(734 - 10, 928 + 10);
  endShape(CLOSE);
  fill(255, 215, 0);
  beginShape();
  vertex(625 - 10, 926 + 10);
  vertex(640 - 10, 850 + flicker * 0.7 - 10);
  vertex(655 - 10, 890 + 10);
  vertex(666 - 10, 800 + flicker * 0.7 - 10);
  vertex(675 - 10, 890 + 10);
  vertex(690 - 10, 850 + flicker * 0.7 - 10);
  vertex(710 - 10, 926 + 10);
  endShape(CLOSE);
}

//embers floating into sky
function drawEmbers() {
  noStroke();
  fill(255, 180, 80);

for (let e of embers) {
    circle(e.x, e.y, e.size);

      e.x += random(2, 7);    
      e.y -= random(-2, 7);  

if (e.x > width || e.y < -50 || e.y > height + 50) {
      e.x = 648 + random(-120, 120);   
      e.y = 904 + random(-80, 80);    
    }
  }
noStroke();

// outer soft glow
fill(255, 120, 40, 40);  
ellipse(648, 904, 420, 180);

// mid glow
fill(255, 150, 50, 70);
ellipse(648, 904, 260, 110);

// inner glow
fill(255, 200, 80, 110);
ellipse(648, 904, 160, 70);
}
